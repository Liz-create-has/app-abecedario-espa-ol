package com.abecedario.contenido;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContenidoServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContenidoServiceApplication.class, args);
	}

}
