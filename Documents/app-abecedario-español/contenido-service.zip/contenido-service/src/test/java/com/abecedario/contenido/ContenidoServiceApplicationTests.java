package com.abecedario.contenido;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContenidoServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
